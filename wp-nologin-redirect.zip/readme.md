    === wp-nologin-redirect ===
    Contributors: YAT, mel_cha
    Tags: nologin,redirect
    Requires at least: 3.9.2
    Tested up to: 4.0
    Stable tag: 4.0
    License: GPLv2 or later
    License URI: http://www.gnu.org/licenses/gpl-2.0.html

    == Description ==     
    When you access in the state where you are not logged in, and redirected to the login screen.
    Be to login, redirected back to the URL you were trying to access.
    
    [日本語の説明]
    ログインしていない状態でアクセスすると、ログイン画面にリダイレクト。ログインすることで、アクセスしようとしていたURLへ再度リダイレクトする。
     
    == Installation ==
     
    1. Upload the the `wp-nologin-redirect` folder to the `/wp-content/plugins/` directory.
    2. Activate the plugin through the 'Plugins' menu in WordPress
     
     
    == Changelog ==
     
    = 0.1.0 =
    * 2013-09-23 First release
